from django.contrib import admin
from .models import *

admin.site.register(Photo)
# Register your models here.
